<?php
// Archivo de configuración o funciones
